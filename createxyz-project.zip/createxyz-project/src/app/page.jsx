"use client";
import React from "react";

function MainComponent() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const projects = [
    {
      id: 1,
      title: "Virtual Mouse Using Iris Detection",
      description:
        "Developed an iris recognition-based virtual mouse with 98% accuracy in detection, boosting user engagement by 25% for disabled individuals. Built using PyCharm, OpenCV, MediaPipe, and PyAutoGUI.",
      image:
        "https://ucarecdn.com/2785ab91-f265-4e87-b3d5-ce770026f556/-/format/auto/",
      github: "https://github.com/Arpitkesar/Eye_controlled_Mouse",
      tech: ["Python", "OpenCV", "MediaPipe", "PyAutoGUI"],
    },
    {
      id: 2,
      title: "To-Do List Application",
      description:
        "A responsive task management application built with ReactJS, featuring dynamic components for adding, editing, and deleting tasks. Optimized performance by 30% using React's virtual DOM.",
      image:
        "https://ucarecdn.com/b7543ecf-853d-4d85-8345-19bf4ba1e14e/-/format/auto/",
      tech: ["React", "HTML", "CSS", "JavaScript"],
    },
    {
      id: 3,
      title: "Netflix Clone",
      description:
        "Built a Netflix Clone web app replicating UI/UX features with dynamic content generation, supporting 100+ users. Ensures 100% cross-device compatibility.",
      image:
        "https://ucarecdn.com/f07e58e3-55c9-4752-b4d6-7badf108c472/-/format/auto/",
      github: "https://github.com/Arpitkesar/Netflix_clone",
      tech: ["HTML", "CSS", "JavaScript", "Git"],
    },
    {
      id: 4,
      title: "IPL Prediction Project",
      description:
        "Developed an advanced predictive analytics model for IPL cricket tournament using machine learning, achieving 80% prediction accuracy. Features data analysis and visualization interface.",
      image:
        "https://ucarecdn.com/93e83a7b-0ecf-4494-8d3d-674770a63496/-/format/auto/",
      github: "https://github.com/Arpitkesar/IPL-Predication",
      tech: ["Python", "Machine Learning", "Data Science"],
    },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[...Array.from({ length: 4 })].map((_, index) => (
              <div
                key={index}
                className="bg-gray-100 dark:bg-gray-800 rounded-lg animate-pulse h-[400px]"
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-12 font-inter">
          Projects
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-gray-50 dark:bg-gray-800/50 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-600 backdrop-blur-sm"
            >
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2 font-inter">
                  {project.title}
                </h2>
                <p className="text-gray-700 dark:text-gray-300 text-sm font-inter mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((tech, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                {project.github && (
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-gray-900 dark:bg-gray-700 text-white rounded hover:bg-gray-700 dark:hover:bg-gray-600 transition-colors font-inter"
                  >
                    <i className="fab fa-github mr-2"></i>
                    View on GitHub
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;